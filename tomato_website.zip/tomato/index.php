<!DOCTYPE html>
<?php
    session_start();
    if(!empty($_POST['Send']) && !empty($_POST['Username'])&& !empty($_POST['Password']))
    {      
        require_once "./website/Login.php";
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name=”viewport” content="width=device-width, user-scalable=yes, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>登入介面</title>

</head>
<body>
<div style="text-align:center">
	<div style="margin-top:5%;text-align:center;">
		<h1>監測番茄成長登入介面</h1>
	</div>
<div style="text-align:center;margin-top:5%;">
<form method="POST" action="">
	<div style="margin:1%;text-align:center;font-size:20px;">
		帳號 :
		<input style="height:10%;" type="text" name="Username" size="40" />
	</div>
	<div style="margin:24px;text-align:center;;font-size:20px;">
		密碼 :
		<input style="height:10%;" type="password" name="Password" size="40" />
	</div>
	<div style="margin-top:10%;text-align:center;">
		<input style="width:7%;height:2%;font-size:15px;" type="submit" name="Send" value="登入" />
	</div>
</form>
</div>

<?php
    
		if(!empty($_POST["Send"]) and $_POST["Send"]=="登入")
		{
			if(!empty($_POST['Result']) and $_POST['Result']=="success")
			{
				$_SESSION['Username']=$_POST['Username'];
				header("Location: ./website/Day/Graph.php"); 
				print_r("登入成功");
			}
			else if(!empty($_POST['Result']) and $_POST['Result']=="failure")
			{
				echo  '<span style=color:red;"font-size: 40px;"> ' . "帳號或密碼錯誤";
			}
			
			else
			{
				echo '<span style=color:red;"font-size: 40px;"> '. "帳號或密碼不可為空白";
			}
		}
?>





</body>
</html>