<?php
$server="localhost";
$username="user1";
$password="1qaz@WSX3edc";
$database="test2";
$conn=new mysqli($server,$username,$password,$database);
mysqli_query($conn,"set names utf8");
if($conn->connect_error){
	die("Connection failed:" . $conn->connect_error);
}
?>